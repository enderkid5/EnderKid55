'''
Created on 24/06/2014

@author: Alejandro
'''

version_string = "0.2.2"
version_numbers = version_string.split('.')
