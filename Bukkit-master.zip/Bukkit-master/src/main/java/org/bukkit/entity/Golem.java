package org.bukkit.entity;

/**
 * A mechanical creature that may harm enemies.
 */
public interface Golem extends Creature {
    
}
