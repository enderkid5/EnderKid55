package org.bukkit.entity;

/**
 * Represents a Cow.
 */
public interface Cow extends Animals {}
