'use strict'

module.exports = {
  defaultVersion: '1.13.2',
  supportedVersions: ['1.7', '1.8', '1.9', '1.10', '1.11.2', '1.12.2', '1.13.2']
}
