'use strict'

const states = {
  'HANDSHAKING': 'handshaking',
  'STATUS': 'status',
  'LOGIN': 'login',
  'PLAY': 'play'
}

module.exports = states
